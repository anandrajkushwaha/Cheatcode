import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

export type AdminStats = {
  configured: boolean;
  posts: number;
  postsLive: number;
  postsScheduled: number;
  postsLast7: number;
  postsPrev7: number;
  waitlist: number;
  waitlistLast7: number;
  avgWords: number;
  avgQuality: number;
  byCategory: { name: string; slug: string; count: number }[];
};

export async function getAdminStats(): Promise<AdminStats> {
  const db = createAdminClient();
  const empty: AdminStats = {
    configured: false, posts: 0, postsLive: 0, postsScheduled: 0, postsLast7: 0,
    postsPrev7: 0, waitlist: 0, waitlistLast7: 0, avgWords: 0, avgQuality: 0, byCategory: [],
  };
  if (!db) return empty;

  const weekAgo = new Date(Date.now() - 7 * 864e5).toISOString();
  const twoWeeksAgo = new Date(Date.now() - 14 * 864e5).toISOString();
  const nowIso = new Date().toISOString();

  const [posts, recent, prior, cats, waitlist, waitlistRecent] = await Promise.all([
    db.from("posts").select("id,word_count,quality_score,category_id,published_at"),
    db.from("posts").select("id", { count: "exact", head: true })
      .gte("published_at", weekAgo).lte("published_at", nowIso),
    db.from("posts").select("id", { count: "exact", head: true })
      .gte("published_at", twoWeeksAgo).lt("published_at", weekAgo),
    db.from("categories").select("id,slug,name").order("sort_order"),
    db.from("waitlist").select("id", { count: "exact", head: true }),
    db.from("waitlist").select("id", { count: "exact", head: true }).gte("created_at", weekAgo),
  ]);

  const rows = posts.data ?? [];

  const catById = Object.fromEntries((cats.data ?? []).map((c) => [c.id, c]));
  const tally: Record<string, number> = {};
  for (const r of rows) {
    const c = catById[(r as { category_id: string }).category_id];
    if (c) tally[c.slug] = (tally[c.slug] ?? 0) + 1;
  }

  return {
    configured: true,
    posts: rows.length,
    postsLive: rows.filter((r) => (r as { published_at: string }).published_at <= nowIso).length,
    postsScheduled: rows.filter((r) => (r as { published_at: string }).published_at > nowIso).length,
    postsLast7: recent.count ?? 0,
    postsPrev7: prior.count ?? 0,
    waitlist: waitlist.count ?? 0,
    waitlistLast7: waitlistRecent.count ?? 0,
    avgWords: rows.length ? Math.round(rows.reduce((a, r) => a + (r.word_count ?? 0), 0) / rows.length) : 0,
    avgQuality: rows.length ? Math.round(rows.reduce((a, r) => a + (r.quality_score ?? 0), 0) / rows.length) : 0,
    byCategory: (cats.data ?? []).map((c) => ({ name: c.name, slug: c.slug, count: tally[c.slug] ?? 0 })),
  };
}


/**
 * Select columns that may not exist yet.
 *
 * The admin panel ships ahead of its migrations: between a deploy and someone
 * running the SQL, a column named here is simply absent, PostgREST rejects the
 * whole request, and `data` comes back null. The Articles table then rendered
 * as "0 articles" — no error, no clue, just a screen insisting the library was
 * empty. Falling back to the columns that definitely exist means a pending
 * migration costs you one feature, not the page.
 */
async function selectOptional<T>(
  run: (cols: string) => PromiseLike<{ data: unknown; error: { message: string } | null }>,
  required: string,
  optional: string[],
): Promise<{ rows: T[]; missing: string[]; error?: string }> {
  const full = [required, ...optional].join(",");
  const first = await run(full);
  if (!first.error) return { rows: (first.data ?? []) as T[], missing: [] };

  const second = await run(required);
  if (second.error) return { rows: [], missing: optional, error: second.error.message };
  return { rows: (second.data ?? []) as T[], missing: optional };
}

export async function getAdminPosts(limit = 100) {
  const db = createAdminClient();
  if (!db) return { rows: [], missing: [] as string[] };

  return selectOptional<Record<string, unknown>>(
    (cols) =>
      db
        .from("posts")
        .select(cols)
        .order("published_at", { ascending: false })
        .limit(limit),
    "id,slug,title,post_type,status,published_at,word_count,quality_score," +
      "focus_keyword,category:categories(name)",
    ["origin"],
  );
}

export async function getWaitlist(limit = 200) {
  const db = createAdminClient();
  if (!db) return [];
  const { data } = await db
    .from("waitlist")
    .select("id,email,source,created_at")
    .order("created_at", { ascending: false })
    .limit(limit);
  return data ?? [];
}

// ---------------------------------------------------------------- analytics

export type Analytics = {
  configured: boolean;
  days: number;
  views: number;
  prev_views: number;
  visitors: number;
  prev_visitors: number;
  unique_users: number;
  prev_users: number;
  views_today: number;
  visitors_today: number;
  users_today: number;
  views_all_time: number;
  users_all_time: number;
  new_users: number;
  returning_users: number;
  sessions_total: number;
  sessions_bounced: number;
  views_per_session: number | null;
  excluded_devices: number;
  bots_blocked: number;
  daily: { day: string; views: number; visitors: number; users: number }[];
  entry_pages: { path: string; views: number }[];
  top_pages: { path: string; views: number; users: number }[];
  top_sources: { source: string; views: number; users: number }[];
  top_countries: { country: string; views: number }[];
  top_cities: { city: string; country: string; views: number }[];
  devices: { device: string; views: number }[];
  top_os: { os: string; views: number; users: number }[];
  top_browsers: { browser: string; views: number; users: number }[];
};

const EMPTY_ANALYTICS: Analytics = {
  configured: false, days: 7, views: 0, prev_views: 0, visitors: 0, prev_visitors: 0,
  unique_users: 0, prev_users: 0, views_today: 0, visitors_today: 0, users_today: 0,
  views_all_time: 0, users_all_time: 0, new_users: 0, returning_users: 0,
  sessions_total: 0, sessions_bounced: 0, views_per_session: null,
  excluded_devices: 0, bots_blocked: 0, daily: [], entry_pages: [], top_pages: [],
  top_sources: [], top_countries: [], top_cities: [], devices: [],
  top_os: [], top_browsers: [],
};

/**
 * Merge an RPC payload onto the defaults, one level into nested objects.
 *
 * A plain spread replaces a nested object wholesale, so when the deployed SQL
 * function is older than this code — the window between pushing and running
 * the migration — a returned `funnel` missing half its keys wiped out the
 * defaults and the screen rendered NaN. Merging per key means a stale function
 * degrades to zeroes instead, which is wrong but readable, and the screen says
 * so rather than printing arithmetic on undefined.
 */
function mergeSummary<T extends object>(base: T, incoming: unknown): T {
  if (!incoming || typeof incoming !== "object") return base;
  const out = { ...base } as Record<string, unknown>;

  for (const [k, v] of Object.entries(incoming as Record<string, unknown>)) {
    const prior = out[k];
    if (
      prior && typeof prior === "object" && !Array.isArray(prior) &&
      v && typeof v === "object" && !Array.isArray(v)
    ) {
      out[k] = { ...(prior as object), ...(v as object) };
    } else if (v !== null && v !== undefined) {
      out[k] = v;
    }
  }
  return out as T;
}

/** True when the deployed SQL predates this code and is missing new fields. */
function isStale(data: unknown, requiredKeys: string[]): boolean {
  if (!data || typeof data !== "object") return false;
  const d = data as Record<string, unknown>;
  return requiredKeys.some((k) => d[k] === undefined);
}

export type AnalyticsResult = Analytics & { stale: boolean; error?: string };

export async function getAnalytics(
  days = 7, from?: string, to?: string,
): Promise<AnalyticsResult> {
  const db = createAdminClient();
  if (!db) return { ...EMPTY_ANALYTICS, stale: false };

  const { data, error } = await db.rpc("analytics_summary", {
    p_days: days,
    ...(from && to ? { p_from: from, p_to: to } : {}),
  });
  if (error) {
    // Most likely cause: the schema files haven't been run yet.
    return { ...EMPTY_ANALYTICS, days, stale: false, error: error.message };
  }
  return {
    ...mergeSummary(EMPTY_ANALYTICS, data),
    configured: true,
    days,
    stale: isStale(data, ["prev_views", "new_users", "entry_pages"]),
  };
}

// ---------------------------------------------------------------- schedule

export async function getScheduledPosts(limit = 200) {
  const db = createAdminClient();
  if (!db) return [];
  const { data } = await db
    .from("posts")
    .select("id,slug,title,post_type,published_at,word_count,quality_score,category:categories(name)")
    .gt("published_at", new Date().toISOString())
    .order("published_at", { ascending: true })
    .limit(limit);
  return data ?? [];
}

export async function getRecentlyPublished(limit = 10) {
  const db = createAdminClient();
  if (!db) return [];
  const { data } = await db
    .from("posts")
    .select("id,slug,title,published_at")
    .lte("published_at", new Date().toISOString())
    .order("published_at", { ascending: false })
    .limit(limit);
  return data ?? [];
}

// ---------------------------------------------------------------- events

export type Funnel = {
  sessions: number;
  read_article: number;
  read_deeply: number;
  opened_tool: number;
  used_tool: number;
  saw_cta: number;
  clicked_cta: number;
  joined: number;
};

export type EventsSummary = {
  days: number;
  total: number;
  bots_blocked: number;
  by_event: { event: string; count: number; sessions: number }[];
  top_ctas: { location: string; label: string; count: number; sessions: number }[];
  outbound: { label: string; count: number }[];
  engagement: {
    avg_scroll: number | null;
    read_75_share: number;
    avg_seconds: number | null;
    median_seconds: number | null;
  };
  tools: {
    ats_runs: number;
    ats_people: number;
    ats_avg_score: number | null;
    ats_failed_read: number;
    ats_bands: { band: string; count: number }[];
    salary_runs: number;
    salary_people: number;
    salary_median_ctc: number | null;
    salary_bands: { band: string; count: number }[];
  };
  funnel: Funnel;
  prev_funnel: { used_tool: number; joined: number };
  /** Event name -> the date it was first ever recorded (YYYY-MM-DD). */
  first_seen: Record<string, string>;
  error?: string;
};

const EMPTY_EVENTS: EventsSummary = {
  days: 7, total: 0, bots_blocked: 0, by_event: [], top_ctas: [], outbound: [],
  engagement: { avg_scroll: null, read_75_share: 0, avg_seconds: null, median_seconds: null },
  tools: {
    ats_runs: 0, ats_people: 0, ats_avg_score: null, ats_failed_read: 0, ats_bands: [],
    salary_runs: 0, salary_people: 0, salary_median_ctc: null, salary_bands: [],
  },
  funnel: {
    sessions: 0, read_article: 0, read_deeply: 0, opened_tool: 0,
    used_tool: 0, saw_cta: 0, clicked_cta: 0, joined: 0,
  },
  prev_funnel: { used_tool: 0, joined: 0 },
  first_seen: {},
};

export type EventsResult = EventsSummary & { stale: boolean };

export async function getEvents(
  days = 7, from?: string, to?: string,
): Promise<EventsResult> {
  const db = createAdminClient();
  if (!db) return { ...EMPTY_EVENTS, stale: false };
  const { data, error } = await db.rpc("events_summary", {
    p_days: days,
    ...(from && to ? { p_from: from, p_to: to } : {}),
  });
  if (error) return { ...EMPTY_EVENTS, days, stale: false, error: error.message };
  return {
    ...mergeSummary(EMPTY_EVENTS, data),
    days,
    stale: isStale(data, ["engagement", "tools"]) ||
      isStale((data as { funnel?: unknown })?.funnel, ["read_article", "saw_cta"]),
  };
}

// ---------------------------------------------------------------- content

export type ContentRow = {
  path: string;
  kind: "article" | "tool" | "listing" | "page";
  views: number;
  readers: number;
  sessions: number;
  entries: number;
  avg_scroll: number;
  finished_share: number;
  avg_seconds: number;
  cta_clicks: number;
  google_views: number;
};

export type ContentPerformance = {
  days: number;
  rows: ContentRow[];
  totals: { pages: number; articles: number; views: number };
  error?: string;
};

const EMPTY_CONTENT: ContentPerformance = {
  days: 30, rows: [], totals: { pages: 0, articles: 0, views: 0 },
};

export async function getContentPerformance(
  days = 30, limit = 200, from?: string, to?: string,
): Promise<ContentPerformance> {
  const db = createAdminClient();
  if (!db) return EMPTY_CONTENT;
  const { data, error } = await db.rpc("content_performance", {
    p_days: days,
    p_limit: limit,
    ...(from && to ? { p_from: from, p_to: to } : {}),
  });
  if (error) return { ...EMPTY_CONTENT, days, error: error.message };
  return { ...mergeSummary(EMPTY_CONTENT, data), days };
}

/** Views per article path, for the Articles table. */
export async function getViewsByPath(
  days = 30,
): Promise<{ byPath: Record<string, ContentRow>; ready: boolean }> {
  const perf = await getContentPerformance(days, 500);
  return {
    byPath: Object.fromEntries(perf.rows.map((r) => [r.path, r])),
    // Without the reporting function every traffic column reads zero, which
    // looks like an article nobody visits rather than a missing migration.
    ready: !perf.error,
  };
}

/** Titles for the article paths a performance row names, so the table reads. */
export async function getPostTitles(paths: string[]): Promise<Record<string, string>> {
  const db = createAdminClient();
  const slugs = paths
    .filter((p) => p.startsWith("/blog/") && !p.startsWith("/blog/category/") && !p.startsWith("/blog/page/"))
    .map((p) => p.replace("/blog/", "").replace(/\/$/, ""));
  if (!db || slugs.length === 0) return {};
  const { data } = await db.from("posts").select("slug,title").in("slug", slugs);
  return Object.fromEntries((data ?? []).map((p) => [`/blog/${p.slug}`, p.title as string]));
}

export type EditablePost = {
  id: string;
  slug: string;
  title: string;
  h1: string | null;
  excerpt: string | null;
  content_html: string;
  category_id: string | null;
  seo_title: string | null;
  seo_description: string | null;
  focus_keyword: string | null;
  cover_image: string | null;
  cover_alt: string | null;
  status: string;
  origin: string;
  published_at: string;
  post_type: string;
  word_count: number | null;
  reading_minutes: number | null;
};

export async function getEditablePost(slug: string): Promise<EditablePost | null> {
  const db = createAdminClient();
  if (!db) return null;
  const { rows } = await selectOptional<EditablePost>(
    (cols) => db.from("posts").select(cols).eq("slug", slug).limit(1),
    "id,slug,title,h1,excerpt,content_html,category_id,seo_title,seo_description," +
      "focus_keyword,status,published_at,post_type,word_count,reading_minutes",
    ["cover_image", "cover_alt", "origin"],
  );
  return rows[0] ?? null;
}

export async function getCategories() {
  const db = createAdminClient();
  if (!db) return [];
  const { data } = await db.from("categories").select("id,slug,name").order("sort_order");
  return (data ?? []) as { id: string; slug: string; name: string }[];
}
