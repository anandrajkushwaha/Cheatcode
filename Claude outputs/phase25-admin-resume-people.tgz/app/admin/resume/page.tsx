import Link from "next/link";
import { Panel, Stat, Empty, num } from "@/components/admin/ui";
import {
  getRecentDownloads,
  getResumeSignals,
  getResumeTotals,
  getTemplateRows,
} from "@/lib/admin/resume";

export const dynamic = "force-dynamic";

/**
 * Résumés: what people build, and what they take away with them.
 *
 * The download is the only event on this screen that means the product
 * worked. A draft started is an intention; a draft downloaded is somebody
 * walking out with a file they will actually send to an employer. So it is
 * the number at the top and the sort order of the template table.
 *
 * ------------------------------------------------------------- two histories
 *
 * Every download figure here comes from one of two places and the screen says
 * which, because they disagree on purpose:
 *
 *   all-time  — summed from `resume_drafts.download_count`, a counter that has
 *               run since the builder shipped. Complete, and dateless.
 *   last 7/28 — counted from `account_events`, one row per download. Dated,
 *               and empty before the recorder shipped.
 *
 * Until the event table has a month in it the second set will look tiny next
 * to the first. Labelling them "all time" and "since tracking started" is what
 * stops that reading as a crash.
 */

const pct = (n: number) => `${(n * 100).toFixed(n >= 0.1 ? 0 : 1)}%`;

function when(iso: string) {
  return new Date(iso).toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "Asia/Kolkata",
  });
}

export default async function AdminResume() {
  const [totals, templates, recent, signals] = await Promise.all([
    getResumeTotals(),
    getTemplateRows(),
    getRecentDownloads(40),
    getResumeSignals(),
  ]);

  if (!totals.ok) {
    return (
      <p className="rounded-xl border border-ink-15 px-4 py-3 text-[0.82rem] text-ink-50">
        Résumé data cannot be read yet — run <code>supabase/schemas/{totals.missing}</code>.
      </p>
    );
  }

  const t = totals.data;
  const rows = templates.ok ? templates.data : [];
  const used = rows.filter((r) => r.downloads > 0);
  const never = rows.filter((r) => r.drafts === 0 && r.downloads === 0);

  return (
    <>
      <header className="mb-8">
        <h1 className="text-[1.3rem] font-semibold tracking-[-0.03em]">Résumés</h1>
        <p className="mt-1.5 text-[0.85rem] leading-relaxed text-ink-50">
          What people build, which templates they finish on, and what they download.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="Downloads"
          value={t.downloadsAllTime}
          hint="all time, from the per-draft counters"
        />
        <Stat
          label="Downloads · 7 days"
          value={t.downloadsLast7}
          hint={t.hasEvents ? "from event rows" : "no events recorded yet"}
        />
        <Stat label="Résumés built" value={t.drafts} hint={`${num(t.draftsLast7)} in the last 7 days`} />
        <Stat
          label="People building"
          value={t.builders}
          hint={`${num(t.draftsDownloaded)} drafts downloaded at least once`}
        />
      </div>

      {!t.hasEvents && (
        <p className="mt-4 rounded-xl border border-ink-15 px-4 py-3 text-[0.8rem] leading-relaxed text-ink-50">
          No dated download events yet. The all-time counters above cover every download
          ever taken; the 7- and 28-day figures only start once somebody downloads a
          résumé after this build is live. Run{" "}
          <code>supabase/schemas/63_resume_events.sql</code> for the index these queries
          use — everything works without it, just more slowly as the table grows.
        </p>
      )}

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <Panel
          title="Templates"
          note={`Sorted by all-time downloads. ${num(used.length)} of ${num(rows.length)} templates have ever been downloaded.`}
        >
          {!templates.ok ? (
            <Empty>
              Cannot read templates — run <code>supabase/schemas/{templates.missing}</code>.
            </Empty>
          ) : !rows.length ? (
            <Empty>No résumés yet.</Empty>
          ) : (
            <div className="-mx-2 overflow-x-auto">
              <table className="w-full min-w-[34rem] text-left text-[0.82rem]">
                <thead className="text-[0.7rem] uppercase tracking-[0.12em] text-ink-30">
                  <tr>
                    <th className="px-2 pb-2 font-medium">Template</th>
                    <th className="px-2 pb-2 text-right font-medium">Built</th>
                    <th className="px-2 pb-2 text-right font-medium">Downloads</th>
                    <th className="px-2 pb-2 text-right font-medium">28d</th>
                    <th className="px-2 pb-2 text-right font-medium">Share</th>
                  </tr>
                </thead>
                <tbody className="tabular-nums">
                  {rows.map((r) => (
                    <tr key={r.id} className="border-t border-ink-08">
                      <td className="px-2 py-2.5">
                        <span className="text-ink">{r.name}</span>
                        {r.layout && (
                          <span className="ml-2 text-[0.72rem] text-ink-30">{r.layout}</span>
                        )}
                      </td>
                      <td className="px-2 py-2.5 text-right text-ink-50">{num(r.drafts)}</td>
                      <td className="px-2 py-2.5 text-right font-medium">{num(r.downloads)}</td>
                      <td className="px-2 py-2.5 text-right text-ink-50">{num(r.recent)}</td>
                      <td className="px-2 py-2.5 text-right text-ink-50">
                        {r.downloads ? pct(r.share) : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {never.length > 0 && (
            <p className="mt-4 text-[0.78rem] leading-relaxed text-ink-30">
              {num(never.length)} templates have never been chosen at all. Worth knowing
              before adding more.
            </p>
          )}
        </Panel>

        <div className="flex min-w-0 flex-col gap-4">
          <Panel
            title="Recent downloads"
            note={t.hasEvents ? undefined : "Starts filling once the recorder is live."}
          >
            {!recent.ok ? (
              <Empty>
                Cannot read events — run <code>supabase/schemas/{recent.missing}</code>.
              </Empty>
            ) : !recent.data.length ? (
              <Empty>Nothing yet.</Empty>
            ) : (
              <ul className="space-y-3">
                {recent.data.map((d, i) => (
                  <li key={`${d.at}-${i}`} className="min-w-0 border-t border-ink-08 pt-3 first:border-0 first:pt-0">
                    <div className="flex items-baseline justify-between gap-3">
                      <Link
                        href={`/admin/users/${d.userId}`}
                        className="truncate text-[0.84rem] underline-offset-4 hover:underline"
                      >
                        {d.who}
                      </Link>
                      <span className="shrink-0 text-[0.72rem] tabular-nums text-ink-30">
                        {when(d.at)}
                      </span>
                    </div>
                    <p className="mt-0.5 truncate text-[0.76rem] text-ink-50">
                      {d.templateName ?? "unknown template"}
                      {d.title ? ` · ${d.title}` : ""}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel title="Other résumé signals" note="Already recorded by the product — all of history, not just since today.">
            {!signals.ok ? (
              <Empty>
                Cannot read — run <code>supabase/schemas/{signals.missing}</code>.
              </Empty>
            ) : (
              <dl className="space-y-2.5 text-[0.84rem]">
                <Row label="Résumés uploaded (ATS scans)" value={num(signals.data.uploads)} hint={`${num(signals.data.uploadsLast7)} in 7 days`} />
                <Row
                  label="Average ATS score"
                  value={signals.data.avgScore === null ? "—" : signals.data.avgScore.toFixed(1)}
                  hint={`${num(signals.data.scored)} scored`}
                />
                <Row label="Opened in the design editor" value={num(signals.data.designed)} hint={`of ${num(t.drafts)} drafts`} />
                <Row label="Shared with a public link" value={num(signals.data.shared)} />
                {signals.data.otherEvents.map((e) => (
                  <Row key={e.kind} label={e.kind} value={num(e.count)} />
                ))}
              </dl>
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}

function Row({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-t border-ink-08 pt-2.5 first:border-0 first:pt-0">
      <dt className="min-w-0 text-ink-50">
        <span className="text-ink">{label}</span>
        {hint && <span className="ml-2 text-[0.72rem] text-ink-30">{hint}</span>}
      </dt>
      <dd className="shrink-0 font-medium tabular-nums">{value}</dd>
    </div>
  );
}
